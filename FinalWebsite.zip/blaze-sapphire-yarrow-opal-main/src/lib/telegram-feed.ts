import { getSql } from "@/lib/db";
import type { NewsTag } from "@/lib/news";

export const TELEGRAM_CHANNEL = "AlphaSignalsPro";
export const TELEGRAM_URL = "https://t.me/AlphaSignalsPro";
const CHANNEL_KEY = "alphasignalspro";

export type TelegramPost = {
  id: number;
  text: string;
  publishedAt: string;
  hasPhoto: boolean;
  hasPhoto2: boolean;
  hasVideo: boolean;
  videoMimeType: string | null;
  messageUrl: string | null;
};

type PostRow = {
  message_id: number | string;
  text: string;
  published_at: string;
  message_url: string | null;
  has_photo: number | boolean;
  has_photo_2: number | boolean;
  has_video?: number | boolean;
  video_mime_type?: string | null;
};

function mapRow(row: PostRow): TelegramPost {
  return {
    id: Number(row.message_id),
    text: row.text,
    publishedAt: new Date(row.published_at).toISOString(),
    hasPhoto: Boolean(row.has_photo),
    hasPhoto2: Boolean(row.has_photo_2),
    hasVideo: Boolean(row.has_video),
    videoMimeType: row.video_mime_type ?? null,
    messageUrl: row.message_url,
  };
}

export function parsePublicId(slug: string): number | null {
  const raw = slug.replace(/^telegram-/i, "").trim();
  const id = Number(raw);
  if (!Number.isSafeInteger(id) || id <= 0) return null;
  return id;
}

export function tagFromText(text: string): NewsTag {
  const head = text.trim().toUpperCase();
  if (head.startsWith("JUST IN")) return "JUST IN";
  if (head.startsWith("BREAKING")) return "BREAKING";
  if (head.startsWith("ALERT")) return "ALERT";
  return "NEW";
}

export function categoryFromText(text: string): string {
  const lower = text.toLowerCase();

  const has = (pattern: RegExp) => pattern.test(lower);

  if (
    has(
      /\b(war|warfare|invasion|ceasefire|airstrike|air strike|missile|drone strike|troops?|military|army|navy|pentagon|nato|sanctions?|hostilities|geopolitics|geopolitical|conflict)\b/,
    ) ||
    has(
      /\b(iran|iranian|tehran|israel|israeli|gaza|hamas|hezbollah|lebanon|houthis?|yemen|syria|ukraine|ukrainian|kyiv|kiev|zelensky)\b/,
    ) ||
    has(/\b(putin|kremlin|moscow|russian army|taiwan|taipei|strait|north korea|pyongyang|kim jong)\b/)
  ) {
    return "Geopolitics";
  }

  if (
    has(/\b(data[- ]cent(?:er|re)s?|hyperscale|gigawatt|\bgw\b|10\s*gw|power grid|interconnect(?:ion)?)\b/) ||
    has(/\b(tsmc|asml|foundry|hbm|nvlink|supercluster|ai campus|ai factory)\b/)
  ) {
    return "AI Infrastructure";
  }

  if (
    has(/\b(openai|anthropic|chatgpt|claude|gemini|grok|xai|deepseek|llm|superintelligence)\b/) ||
    has(/\b(nvidia|gpu|gpus|semiconductor|ai model|language model)\b/) ||
    has(/\bai\b/)
  ) {
    return "AI";
  }

  if (
    has(/\b(federal reserve|the fed|fed|fomc|powell|warsh|jackson hole)\b/) ||
    has(/\b(cpi|pce|nfp|nonfarm|inflation|rate[- ]hike|rate[- ]cut|basis points?|bps)\b/) ||
    has(/\b(ecb|boj|gdp|unemployment|jobs report|treasury yield|dxy|dollar index)\b/)
  ) {
    return "Macro";
  }

  if (
    has(/\b(earnings|ipo|share price|stock price|equit(?:y|ies)|listed shares)\b/) ||
    has(/\b(tesla|apple|microsoft|amazon|alphabet|google|meta|microstrategy|strategy)\b/) ||
    has(/\b(tslab|aaplb|mstrb|nvdab|spcxb|bstocks?)\b/)
  ) {
    return "Equities";
  }

  if (
    has(/\b(s&p|s & p|nasdaq|dow jones|kospi|hang seng|nikkei|stoxx)\b/) ||
    has(/\b(crude|brent|wti|oil price|gold|silver|copper|commodit(?:y|ies)|yield curve)\b/) ||
    has(/\b(risk[- ]on|risk[- ]off|selloff|sell-off|rally)\b/)
  ) {
    return "Markets";
  }

  if (
    has(/\b(bitcoin|btc|ethereum|ether|\beth\b|solana|\bsol\b|xrp|ripple|crypto|defi|stablecoin|altcoin)\b/)
  ) {
    return "Crypto";
  }

  return "Crypto";
}

export function splitHeadline(text: string) {
  const lines = text.split("\n").map((line) => line.trim()).filter(Boolean);
  const headline = lines[0] || text.slice(0, 140);
  const dek = lines.slice(1).join(" ");
  return { headline, dek, body: lines.slice(1) };
}

export async function listTelegramPosts(limit = 10): Promise<TelegramPost[]> {
  const sql = await getSql();
  const rows = await sql.query<PostRow>(
    `select message_id, text, published_at, message_url,
            case when photo_file_id is not null or photo_data is not null then 1 else 0 end as has_photo,
            case when photo_data_2 is not null then 1 else 0 end as has_photo_2,
            case when video_data is not null then 1 else 0 end as has_video,
            video_mime_type
       from telegram_posts
      where lower(replace(coalesce(chat_username, ''), '@', '')) = $1
      order by published_at desc
      limit $2`,
    [CHANNEL_KEY, Math.min(Math.max(limit, 1), 80)],
  );
  return rows.map(mapRow);
}

export async function getTelegramPost(id: number): Promise<TelegramPost | null> {
  const sql = await getSql();
  const rows = await sql.query<PostRow>(
    `select message_id, text, published_at, message_url,
            case when photo_file_id is not null or photo_data is not null then 1 else 0 end as has_photo,
            case when photo_data_2 is not null then 1 else 0 end as has_photo_2,
            case when video_data is not null then 1 else 0 end as has_video,
            video_mime_type
       from telegram_posts
      where lower(replace(coalesce(chat_username, ''), '@', '')) = $1
        and (message_id = $2 or id = $2)
      order by published_at desc
      limit 1`,
    [CHANNEL_KEY, id],
  );
  return rows[0] ? mapRow(rows[0]) : null;
}

export async function getTelegramPhoto(id: number, photoNumber = 1) {
  const sql = await getSql();
  const column = photoNumber === 2 ? "photo_data_2" : "photo_data";
  const mimeColumn = photoNumber === 2 ? "photo_mime_type_2" : "photo_mime_type";
  const rows = await sql.query<{ photo_data: Uint8Array | ArrayBuffer | null; photo_mime_type: string | null }>(
    `select ${column} as photo_data, ${mimeColumn} as photo_mime_type
       from telegram_posts
      where (message_id = $1 or id = $1)
        and lower(replace(coalesce(chat_username, ''), '@', '')) = $2
      order by published_at desc
      limit 1`,
    [id, CHANNEL_KEY],
  );
  return rows[0] ?? null;
}

export async function getTelegramVideo(id: number) {
  const sql = await getSql();
  const rows = await sql.query<{ video_data: Uint8Array | ArrayBuffer | null; video_mime_type: string | null }>(
    `select video_data, video_mime_type
       from telegram_posts
      where (message_id = $1 or id = $1)
        and lower(replace(coalesce(chat_username, ''), '@', '')) = $2
      order by published_at desc
      limit 1`,
    [id, CHANNEL_KEY],
  );
  return rows[0] ?? null;
}
